#define DELIMITER           1
#define INTCONST            2
#define FLOAT               3
#define STRING              4
#define IDENTIFIER          5
#define COMMENT             6
#define WHITE_SPACES        7
#define OPERATOR            8
#define KEYWORD             9
#define OPEN_BRACKETS       10
#define CLOSE_BRACKETS      11
#define OPEN_BRACES         12
#define CLOSE_BRACES        13
#define OPEN_PARENTHESES    14
#define CLOSE_PARENTHESES   15
#define PUNCTUATOR          16
/*#define FILL ME */
