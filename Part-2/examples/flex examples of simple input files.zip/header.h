#define INTEGER_LITERAL 1
#define PLUS 2
#define MULT 3
